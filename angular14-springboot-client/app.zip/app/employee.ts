export class Employee {
  id: number;
  firstName: string;
  lastName: String;
  emailId: string;
  active: boolean;
}
